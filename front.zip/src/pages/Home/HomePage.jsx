import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Grid, Typography, Box, CircularProgress } from '@mui/material';
import RealtyCard from '../../components/realty/RealtyCard';
import RealtyFilters from '../../components/realty/RealtyFilters';
import Pagination from '../../components/common/Pagination';
import Header from '../../components/common/Header';
import Footer from '../../components/common/Footer';
//import heroImage from '../../assets/images/hero.jpg';

const HomePage = () => {
  const [realtyList, setRealtyList] = useState([]);
  const [filteredRealtyList, setFilteredRealtyList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    rooms: '',
    beds: '',
    minPrice: '',
    maxPrice: '',
    distanceToSea: '',
    distanceToCenter: '',
  });
  const [sortConfig, setSortConfig] = useState({ key: 'price', direction: 'asc' });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  useEffect(() => {
    const fetchRealtyList = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/realty/');
        setRealtyList(response.data);
        setFilteredRealtyList(response.data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchRealtyList();
  }, []);

  useEffect(() => {
    let result = [...realtyList];

    // Применение фильтров
    if (filters.rooms) {
      result = result.filter(item => item.rooms == filters.rooms);
    }
    if (filters.beds) {
      result = result.filter(item => item.beds == filters.beds);
    }
    if (filters.minPrice) {
      result = result.filter(item => item.price >= filters.minPrice);
    }
    if (filters.maxPrice) {
      result = result.filter(item => item.price <= filters.maxPrice);
    }
    if (filters.distanceToSea) {
      result = result.filter(item => item.distance_to_sea <= filters.distanceToSea);
    }
    if (filters.distanceToCenter) {
      result = result.filter(item => item.distance_to_center <= filters.distanceToCenter);
    }

    // Применение сортировки
    if (sortConfig.key) {
      result.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    setFilteredRealtyList(result);
    setCurrentPage(1);
  }, [filters, sortConfig, realtyList]);

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleSortChange = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredRealtyList.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredRealtyList.length / itemsPerPage);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <Typography color="error">Error: {error}</Typography>
      </Box>
    );
  }

  return (
    <>
      <Header />

      {/* Hero Section */}
      <Box
        sx={{
          height: '180px',
          //backgroundImage: `url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          textAlign: 'center',
          mb: 4,
        }}
      >
        <Box sx={{ backgroundColor: 'rgba(0,0,0,0.5)', p: 4, borderRadius: 2 }}>
          <Typography variant="h4" component="h3" gutterBottom>
            Найдите идеальное жилье для отдыха
          </Typography>
          <Typography variant="h5">
            Арендуйте уютные апартаменты у моря по лучшим ценам
          </Typography>
        </Box>
      </Box>

      <Container maxWidth="xl">
        <RealtyFilters
          filters={filters}
          onFilterChange={handleFilterChange}
          sortConfig={sortConfig}
          onSortChange={handleSortChange}
        />

        {filteredRealtyList.length === 0 ? (
          <Box textAlign="center" my={4}>
            <Typography variant="h5">Нет объектов, соответствующих вашим критериям</Typography>
          </Box>
        ) : (
          <>
            <Grid container spacing={4} sx={{ mb: 4 }}>
              {currentItems.map((item) => (
                <Grid item key={item.id} xs={12} sm={6} md={4}>
                  <RealtyCard realty={item} />
                </Grid>
              ))}
            </Grid>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </>
        )}
      </Container>

      <Footer />
    </>
  );
};

export default HomePage;